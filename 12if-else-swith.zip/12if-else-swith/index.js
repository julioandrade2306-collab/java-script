

// ======== VARIÁVEIS GLOBAIS ========
let contarVal = 0;
let contarVal2 = 0;
let valorCorreto = 14;
let ganhou = Math.floor(Math.random() * 8) + 1;

// ======== IF / ELSE ========
function ligar() {
    var valor1 = Number(document.getElementById("numero").value);
    var valor2 = valorCorreto;
    
    if(valor1 == valor2) {
        document.getElementById("botao1").style.backgroundColor = "yellow";
        document.getElementById("botao1").style.color = "red";
        document.getElementById("numero2").innerHTML = "Acertou!";
    } else if (valor1 < 10) {
        document.getElementById("numero2").innerHTML = "Não foi dessa vez!";
    } else if (valor1 < 14) {
        document.getElementById("numero2").innerHTML = "Continue tentando!!";
    } else {
        document.getElementById("numero2").innerHTML = "Errado! Tente novamente.";
    }
}

// ======== SWITCH ========
function verificarnumero(){
    let teste1 = document.getElementById("testenumero").value;
    switch(teste1){
        case "2":
            document.getElementById("botao10").style.backgroundColor = "yellow";
            document.getElementById("numero3").innerHTML = "Parabéns, você acertou um número!";
            document.getElementById("botao10").style.color = "red";
            break;
        default:
            document.getElementById("numero3").innerHTML = "Não foi dessa vez, tente novamente!";
    }
}

// ======== JOGO DAS CAIXAS ========
function testar(elem){
    var num = parseInt(elem.innerHTML);
    if(num === ganhou){
        document.querySelector("#resposta").innerHTML = "Parabéns!! Você achou a caixa correta!";
        document.querySelector("#resposta").style.backgroundColor = "yellow";
    } else {
        document.querySelector("#resposta").innerHTML = "Errou! Continue tentando.";
    }
}

// ======== CONTADORES ========
function contarClick(){
    updateDisplay(++contarVal);
}
function contarClick2(){
    updateDisplay2(++contarVal2);
}
function updateDisplay(val){
    document.getElementById("contartentativas").innerHTML = val;
}
function updateDisplay2(val){
    document.getElementById("contartentativas2").innerHTML = val;
}

// ======== RESET ========
function resetarContador(){
    contarVal = 0;
    contarVal2 = 0;
    ganhou = Math.floor(Math.random() * 8) + 1;
    updateDisplay(0);
    updateDisplay2(0);
    document.getElementById("numero2").innerHTML = "";
    document.getElementById("numero3").innerHTML = "";
    document.getElementById("resposta").innerHTML = "";
    document.getElementById("botao1").style.backgroundColor = "black";
    document.getElementById("botao1").style.color = "white";
    document.getElementById("botao10").style.backgroundColor = "black";
    document.getElementById("botao10").style.color = "white";
    const caixas = document.querySelectorAll(".caixa");
    caixas.forEach(caixa => caixa.style.backgroundColor = "darkturquoise");
}
